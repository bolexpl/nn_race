/* 
 * File: _coder_forcoder_info.h 
 *  
 * MATLAB Coder version            : 4.2 
 * C/C++ source code generated on  : 16-Jun-2021 00:25:03 
 */

#ifndef _CODER_FORCODER_INFO_H
#define _CODER_FORCODER_INFO_H
/* Include Files */ 
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"


/* Function Declarations */ 
extern const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#endif
/* 
 * File trailer for _coder_forcoder_info.h 
 *  
 * [EOF] 
 */
