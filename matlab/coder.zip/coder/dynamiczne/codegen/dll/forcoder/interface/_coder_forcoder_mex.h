/*
 * File: _coder_forcoder_mex.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 16-Jun-2021 00:25:03
 */

#ifndef _CODER_FORCODER_MEX_H
#define _CODER_FORCODER_MEX_H

/* Include Files */
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include "_coder_forcoder_api.h"

/* Function Declarations */
#ifdef __cplusplus

extern "C" {

#endif

  extern void mexFunction(int32_T nlhs, mxArray *plhs[], int32_T nrhs, const
    mxArray *prhs[]);
  extern emlrtCTX mexFunctionCreateRootTLS(void);

#ifdef __cplusplus

}
#endif
#endif

/*
 * File trailer for _coder_forcoder_mex.h
 *
 * [EOF]
 */
