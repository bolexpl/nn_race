/*
 * File: forcoder_initialize.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 16-Jun-2021 00:25:03
 */

#ifndef FORCODER_INITIALIZE_H
#define FORCODER_INITIALIZE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "forcoder_types.h"

/* Function Declarations */
#ifdef __cplusplus

extern "C" {

#endif

  extern void forcoder_initialize(void);

#ifdef __cplusplus

}
#endif
#endif

/*
 * File trailer for forcoder_initialize.h
 *
 * [EOF]
 */
