/*
 * File: forcoder_terminate.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 16-Jun-2021 00:25:03
 */

/* Include Files */
#include "forcoder.h"
#include "forcoder_terminate.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void forcoder_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for forcoder_terminate.c
 *
 * [EOF]
 */
