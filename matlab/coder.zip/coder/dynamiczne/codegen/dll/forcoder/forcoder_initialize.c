/*
 * File: forcoder_initialize.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 16-Jun-2021 00:25:03
 */

/* Include Files */
#include "forcoder.h"
#include "forcoder_initialize.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void forcoder_initialize(void)
{
}

/*
 * File trailer for forcoder_initialize.c
 *
 * [EOF]
 */
