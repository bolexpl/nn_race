/*
 * File: forcoder_types.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 16-Jun-2021 00:25:03
 */

#ifndef FORCODER_TYPES_H
#define FORCODER_TYPES_H

/* Include Files */
#include "rtwtypes.h"
#endif

/*
 * File trailer for forcoder_types.h
 *
 * [EOF]
 */
