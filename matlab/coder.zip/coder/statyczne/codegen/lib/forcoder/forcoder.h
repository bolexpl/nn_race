/*
 * File: forcoder.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 16-Jun-2021 00:23:38
 */

#ifndef FORCODER_H
#define FORCODER_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "forcoder_types.h"

/* Function Declarations */
extern void forcoder(const double x1[6], double b_y1[2]);

#endif

/*
 * File trailer for forcoder.h
 *
 * [EOF]
 */
