/*
 * File: _coder_forcoder_api.h
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 16-Jun-2021 00:23:38
 */

#ifndef _CODER_FORCODER_API_H
#define _CODER_FORCODER_API_H

/* Include Files */
#include "tmwtypes.h"
#include "mex.h"
#include "emlrt.h"
#include <stddef.h>
#include <stdlib.h>
#include "_coder_forcoder_api.h"

/* Variable Declarations */
extern emlrtCTX emlrtRootTLSGlobal;
extern emlrtContext emlrtContextGlobal;

/* Function Declarations */
extern void forcoder(real_T x1[6], real_T b_y1[2]);
extern void forcoder_api(const mxArray * const prhs[1], int32_T nlhs, const
  mxArray *plhs[1]);
extern void forcoder_atexit(void);
extern void forcoder_initialize(void);
extern void forcoder_terminate(void);
extern void forcoder_xil_shutdown(void);
extern void forcoder_xil_terminate(void);

#endif

/*
 * File trailer for _coder_forcoder_api.h
 *
 * [EOF]
 */
