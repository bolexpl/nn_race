/*
 * File: _coder_forcoder_info.c
 *
 * MATLAB Coder version            : 4.2
 * C/C++ source code generated on  : 16-Jun-2021 00:23:38
 */

/* Include Files */
#include "_coder_forcoder_info.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : const mxArray *
 */
const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char * data[36] = {
    "789ced5ddd6febc875e76ef606bb0f6dd42e92dd34fd58a7c522c106962c4b967d8bb6fab064cbd6a7655b966fefb529919278c52f91942ce9490b14450bb4c0"
    "fe0105fa943c1408b07d6a801485d2e6a148f2b8098200419efa903c14418004c843d292a2e86b72352b5e6b3432a533b8bb63ea90f31b1e9c39bf99331fa45e",
    "49675fa128ea77f5ff8c7c7465fc9fa27e8732936f92bf4ad99353feca247fecb8b6d223ea35db7396fc9f26794d1235b6a799173c27b2b98e506515fd42a405"
    "f6b6184612389116b5d3becc520aab4a7c9765c6923ac7b3a79cc066a43b17879c7e21a4ee886e2f0c91f177a2c9d65aa58e40294df54575f9bb17d45dfd20de",
    "ff3597fa7986d08fcf217f927c9a78ec3f535945f557259e6df9f7a55a4760454df51f488ca4f945f14aa16bac5fa0359eaefa6b12c32a7e55a335aee6dfdc34"
    "fed52565fceba6b021d0b2ae3881ee5dd1b2ccf75fbc4f0f51df4fbb7c9f4f21dee78d49feb6edd76c749c0d2739958b5af5b846e0b8d5eba71dd7d4ed7da6a4",
    "aaf6ea1df1c57bcb73e27d06896797eba0358d93c4ab262d323c7b8bffe19cf8d919f896fc493a73917cbaffd85f50a486420bef1836affa0b12df5765c37c4e"
    "8281ad3ddaaf49125f957a7e56e0fd3c57b5ac8ae5f53ffca6f23605ea85feae11f5736b37cedc4a6f50af5b7ffef4abe20f6204f1c6695df050eddeadfd7d0e",
    "81e773c88be7a1ed6aeda656490de8602b11dc3d3829d6122fea51988133ab1e14e29a54f9d08ea7d7df6e775bb77e7e8828cfadbefe1881e773c8f5f7bfe244"
    "ed4ae7405e92e42ba9cb2a755ebab9aa197c3ffbfd67d5c79950f5b19285f7dff7c4b3caafcdc0b3e4f3da8b7ef9c92a1c5b11493b1afdfbff3c023ef03a1fa8",
    "c7c95e727f30281cf582a16c309028c6b602c9d5e1839f239e77abc7bf4794ef73c809b4ef8d4fbee1aac9f2f2788476f7fdaf11ef87d76e0fb08d1b5e735c53"
    "b7f799124ead1b63486cede42d249e5d6e0edc74edb38a48f3fa1f0cdb4b8b1ab67e477a463d2cf97dedaccef5584696f417f01b2a9cb005513bf9c62f7ff47d",
    "e08b05e191e28b525fe68470fba4bcc5559950fab258c86e75f757872fa01d4fafbfddee02b7fe7edeb88d33fe4839eeb3e49c2a760456e16a9a11699c7fbce0"
    "966f6a4d7a4ca916de37e6c43b41e2d9e558ece38eca2c432168275f2f7f1efcbdd7fdfdc176ab5f6a37383e719a689db4e38dd3d6597285fc3d8c0fa6bf1f5e",
    "bb4d139b57d0df5fa07bcbe3074fc51f4d65118e3f0e1fbdff43881b799d172a0a7d58ea56bbd5c809bb9fec0be1bd7285055e005e40e456b2d9ed902c2f7022"
    "f0826b5ee048cf4b8dbef9d61bc00b5ee785065d89e4b7cbb976a41ad312613a1f6243c583d5e1054fb5e329f3cb64d7171d45c7d9d0ca8fa3b8ecf19e717bb5",
    "46f3b4926c60e38159bcc3489d2acfe28b1f95907876f97decc7f8ef3d73ddda7b96c6fc96c6c8cf2fffa2f25de08387ca079f45e0f91cf25848ac4b4701ae14"
    "a8ec140a5b99462c1ce2a9d5e10368cfd3732bd9fbfbd995993720edf761de606178e3b42e78306f80a77cf0fbd3732ba1fc3e0acfadde5e775c53b7f7991263",
    "525c1ffa3497e5e71ffaf8d0b17ec05015e9f5c7e0df178847aa5fdf6db349b95b53f72e6eb625a9a096b6b62b97d4eaf8f711e279b77a7c8228dfe7902fc0bf"
    "6fd43945d5cc659264edf09a5eda3ad079f148fbf935582706eb3d178807eb3df1943f423cef053f3f601549edd8fbf3a8b88a5b3b7cd5716d252bbeefbbfbe3",
    "e869749c479f11f3fbf50e6f840f3debf709cdffe8f728f58ee837d4457a7dcfbf42ffdefb7e5fdb090a27fbe583e6e5b634e86a592195ddd256c8efcfbbefb3"
    "8128dfe790639dc7dd181f1611e7445ae997c63c909a1c6740d61ea3256cf3b86ec79b8e795c9e151b5a935adebee179e37fc51978961c5bbfc1d4d812c601d1",
    "67df7e13e6711f2a1fb86d7fa799f3cb3d81b95062e550a4b7b57d2e0472c714f001f0819e4665384f82c26347709ec47af86dd278709e049ef2e71dffe710e5"
    "fb1c72bce7cd2d293e44a5a2e36c88ef7c8859f11a85957585407cc8553fc25416e9f8d04fb25f033fef753f9f39bc496a7bf1d36e3e1838ededc84c6ca71587",
    "73e4d6a81d1be94bd8e2406f3bae29c77d96dc1107d2473e0d4eac355bcbeaef8fee8967957f3503cf92bfac9da84d5a619949af60120b7286846e95a75b0e41"
    "ffffe6e3938fc0ff2f088f94ffeff76ed27b74aade08076af9a4547a9eea446e56a89f3f423cefd5764d76dfd717a366feee24ff0ab6feff23443d7c13499d97",
    "2463e3ad57fbff19249e5d3e77bf613c3b6c28cb0cf410f457df3a7b17e687bdeeff77db91fc699bdf0fb7e2cdd3e241496befefd752abe3ffa11d4fafbfddee"
    "dec116f7ff13049ecf21779ec3a9c63b1cafa5c59cb96569697e7fdeb87f1d8967972fa2bfe054e2dd78e135a2de18ede83bd46f211ee4753eb8b98c9f0d06bd",
    "66242f7792c960a2163ea177e3c007ebc5077f868d0fbe80c0f339e453cf77d8b44601de5d1f743103cf92635b1ff49ea93acb7608c683fe05d68b7adfff579b"
    "3b850b91d7989224243be2e17635193f82737fd6d6ff7f8028cfadbebe8cc0f339e40eff3f5e10655f0a95160bbcaeb8c9fdb3e6c1497d6f6cdef102ebb876e2",
    "5b726cfc80d62ce979a762f967305ef03a5f740a89442f9228cbb9d3301bc935b7b399486b85e68f57b57da3fce662d60f7d256ae66182e747185ba754765971"
    "a487bcaf60cafe324b5dcbd857f0fa5f3c031ef03a0fdc94d36a8a6f9da78275a5c4779fe78fc4411178e0c1f3c035a2de78ed7173e5e249cbe20588272d0acf",
    "4ceb8207f1243ce5cf1b4fca22caf739e4de5e5ffae7b7feffef10e5b9d5d70602cfe7903be349aaca2ada39cd734c891bb031c5dac7b72c1e18cd89f7148967"
    "97e3eb4f7c4c83a4bf2bf06ae206c6095ee78360b035d8db4fc5d38d4caf743938ac1eee9d68b0de748ddbb59e8651880bb9c483b8d0a2f0ccb42e781017c253",
    "fe08f13cf87b7bb2fbfb18ac379ddc03eb4da7bf970b3b82f5a60bc483f5a678ca9fb77d3711e5fb1cf285f2c306a71a72bd5c9ea83d8e2ac4f69b196f68f84a"
    "d86fe6e6bb9286b248af4b1bc239d40bc423e5efc3bd2c9f6a7599e7e99d8bde11a30443626907f69bad513b3612befd05d0ff47e1d9e5d0ff9f1b6f9cd6050f",
    "faff78ca5f9dfe7f55ea888c4ab6ff5fc4c6137f84c0f339e41fe389b431f0619504af2b86c2373e78d9efce8fe6c4ab20f1ec726c7664d7dc32e60ffee173f0"
    "1d7acff3434acc14e2b1726ec009bdfc739911f25aaebf42f307c00fd3dfcb1d3f9c618b0fcdeab7ebef2fd0bde5f9ff79c79559249e5d8e675c395616e9f348",
    "1fbdff43f0f75ef7f715853e2c75abdd6ae484dd4ff685f05eb9c2c2f76ac0df8fd339517fcf89e0ef5dfb7b4e24bd1ef49b6f41ffdef3febe415722f9ed72ae"
    "1da9c6b44498ce87d8507185f6078c10cfc3fa207bb2af0fca809f7789077e1e379e99d6050ffc3c9ef24788e7c1cfdb93ddcfe7207ee3120fe237b8f1ccb42e",
    "7810bfc153bea7daf194fdbe32a27e0b39f767188f9a39be795cf8aee427e3c1772571e199695df0e0bb9278caf73a3f5c23ea87d7ee8eb19d07f1a7083c9f43"
    "ee3c0fa22b714c4c51e87e8aa7358d1539d13c116259bc30ba279e55fea2be53841e3f4ed120d1ef8f51c35f55810fbcce0783a3c3edc4997c2114ab79267651",
    "3fccf684fc21f0c17af141368acbeede42e0f91cf2a9e7c3251b4bdb0730efb91025249e5d8ecdff5b1a233f0ef845e5bbe0f71faadfff2c02cfe790c742625d"
    "3a0a70a54065a750d8ca3462e1104f81df5f2fbf9f5fb6df97158951b9018bcdefbfecbc80e7fcbea531e27e7ff86fb0fff7e1fa7db7fdfd56bb948bc9e96a9e",
    "4bcbb9b366f76c37d0d65668bfd7bc7e3f8728dfe7903f493e4d3cf69fa9aca2faab12cfb6fcfb52ad23b0a2a6fa0f2446d2fca278a5180d7be2e9cd76ac6ab4"
    "c6d5fc9b9bc6bfbaa498ee5058d2fc00958a8eb3e101361ef83d04becf213782db82c609ac7ad56479995526bf2f2bfe332f0f9ccfc0b3e473f6172459f57f4c",
    "7584f7fdfef87fbf07fd7faff34021ce947a97fd666a2b33081e35235db1b81f59a179e279e7f91844f93e877c31ed79a3260982249a337deaddf722ca0fc37c"
    "749c470b705e0485c7aee0bc88f5f0e3a4f1e0bc083ce5433f707a6e25d43cf210519e5bbdfd0102cfe7903b78a1cad3eaa6a90453eed5f9833212cf2ec7f75d",
    "1943757e537544e78d87d5ff8075a69ee781f8f3523b5d14e369e132456b1787e5e707bdf80aed2780f63c3db7d2a2ce939b87073891e7c4c987dcbc1a475a92"
    "dd98aa236b373bafbfff11f0c082f088f140958ea9f15ca8d0e5778ba2a6ed965bed36f0c0b2dbf39278e04bcb9e4f867544b08e088167a675c183754478ca1f",
    "219e77abc72788f27d0ef902daf3469d5354adced9dee71a515fac7618a561bfd9e41ed86f36fdbd5cf003ec375b201eec37c353feaa8c0f3e40d4d3adfda1fa"
    "c9d6bc72e0ee8fc3c9ba23eac0cc87939c3a9c5c4f722abdecf1c424aea479369e743a03cf92638f2769a4bf6b11fdbfbffd4be00baff385dc48abf570afd80d",
    "ee25758b8c24daa9337e85f6a3ad0a5f5c23ea89d7fe32d8c611f7fcfec0d8ff6b4d85559b126facf95ad63e85d19c7897483cbb1cb3dddcaacefa0001413e78"
    "92fc2fd8afe0753ec832e77bf9dc6ee72075c4e4da52be70b63fd886f1c39af201be738ceeb90e75cc071d95bd52d8baf1b767cfabf8eb1978961cb3dddc511d",
    "e9f1c1e89f99afc1f8c0eb7c2057bbb9e05eb0c497b62eb2f1da5e20cc48fb2bb4fe7484781efb7c03d6fd6b1b1a2daa5ce38a9665be6f7b9f6b447df1ce37bc"
    "d89f00fbd75e0ecf2a7f8dd62dc3feb505e2c1fe353ce58f10cf030fd8138a0750786ef5f729049e6f22617bf2385fd63aa30fe7c43b42e2d9e5739f6f52ef88",
    "7e5d59e4e33fd4b7cede85f88fd7fd7c3f50bec87237f9a39d8cc4dda483bba1b3fed60aad2f85763cbdfe76bbfb22b6b8cfe711783e877ceabad24dcbeb433f"
    "df7ddcc7549d653b04e33d7ff39bff04ffef75ff9fae1fd5b70e33da6e99de6a9fd77201fae2b0b942fd7cf0ffd3eb8ff2ff1f20ca73abaf2f23f07c0eb9f3bc",
    "6a6340531a7bb25447ac699c24a6c502af2b6e72bf553f8b1fee5bbfcfcca89f25af4f6a71d5a445867f717edebceb4d59c7b513df92e33bc71aa959d2e72116"
    "cb3f83b890d7f9a25348247a914459ce9d86d948aeb99dcd445a89d5e10b68dfd3dfcb9d3d6edff2087cf7c0bc67744f3cab7cf8eec1c2f1c6695df0e0bb0778",
    "ca079e98fe5eeeec31b2ec75a71d952dd04a5d521292a86a9477d79d5690787639363bb26bce1aae12b49f61e9c90ef083d7f9a1df16e4bd8bbd233e74ce358b"
    "6cfcb0d7ed565628ee34423c0fedda9eec76b88b8d17be80c0f339e40e5ed02ff5fe6e4a520e0a6763b957e72188af5bbeab39b2e385cd6c09f8c0eb7c100933",
    "c7a7194ea9261af5e30bfa868b0d762b2bb40f01c60bd3dfcb9d3dfe159c7741e1b12338ef623dfc36693c38ef024ff9c013d3dfcb9d3d46576e1d93854ffa9c"
    "3c58c7b4283c33ad0b1eac63c253fe08f13cec57b027d47e8521a2bc05cf33280cd7e518f6c51e36afce43138f47da35b78c79868ffef107305ef03a2fe404fa",
    "38580f48e259a5c02ac7c799729949c37ee607dbaead7ef37dedf0e5becfb91935f3ad659f7b01df5f83efafbd2cde38ad0b1e7c7f0d4ff923c4f35ee58b6b44"
    "7d17b5ae758828cfadfede41e0f91cf2297125b627272441d6075abac75e163f8ce6c4237e2ed2c73447fcdcd467df7e1378c1ebbcd06464e5f26290ac3522fb",
    "99487fbb43c78ac00bebce0bb1282e3bfc7d049ecf2177f082ae04f3f765f1c18773e2e59078763936bbd13546765c10fdc35f33e0ffbdeeff1b914bb6506c76"
    "9976fa79e2542e277372595ca179e711e279b77abc4694ef73c831cf2f08b42c70a240f7ae14b6ab97c9ceb20bb776883a9fc88a23bd7df7c761313ace47939c",
    "3a8992f2c755b557ef880f677ff4bc7c909d816fc9e7de6fafffe13795477a9dc24fbf2a021f789d0f8ae7a1ed6aeda656490de8602b11dc3d3829d656601ff4"
    "ff032a57065e", "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(data, 90072U, &nameCaptureInfo);
  return nameCaptureInfo;
}

/*
 * Arguments    : void
 * Return Type  : mxArray *
 */
mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xResult;
  mxArray *xEntryPoints;
  const char * fldNames[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  mxArray *xInputs;
  const char * b_fldNames[4] = { "Version", "ResolvedFunctions", "EntryPoints",
    "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, fldNames);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("forcoder"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(""));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar(0.0));
  xResult = emlrtCreateStructMatrix(1, 1, 4, b_fldNames);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.6.0.1072779 (R2019a)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/*
 * File trailer for _coder_forcoder_info.c
 *
 * [EOF]
 */
